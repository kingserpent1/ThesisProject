﻿using UnityEngine;
using System.Collections;
using UnityEngine.Audio;

public class AudioManager : MonoBehaviour 
{

    public GameObject[] mx;
    public uint musicChannels = 2;
    public static AudioManager _instance = null;

    //public
    public bool isWorldPlaying = false;
    public bool isMusicPlaying = false;
    public bool isActivePlaying = false;

    //private
    public AudioMixer musicMixer = null;

    public static AudioManager instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = FindObjectOfType(typeof(AudioManager)) as AudioManager;
                GameObject obj = new GameObject("AudioManager");
                _instance = obj.AddComponent(typeof(AudioManager)) as AudioManager;

                _instance.Init();
            }
            return _instance;
        }
    }

    private void Awake()
    {
        AudioManager.instance.Create();
    }


    public void Create() { }

    //Constructor
    void Init()
    {
        isWorldPlaying = false;
        isMusicPlaying = false;
        isActivePlaying = false;

        musicMixer = Resources.Load("Music") as AudioMixer; //set up audio Mixer outputs

        for (int i = 0; i < mx.Length; i++)
        {
            //mx[i] = new GameObject("MusicChannel" + i.ToString)
        }

        //setup any routing, audio clips
    }

    void PlayWorldMusic()
    {

    }
}
