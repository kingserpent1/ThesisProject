﻿using UnityEngine;
using System.Collections;
using UnityEngine.Audio;

public class Manager : MonoBehaviour
{
    public AudioSource dialogue = null;
    public bool isOpen = false;
    public string[] inventory;
    public string[] items;


    public void init()
    {
        for (int i = 0; i < items.Length; ++i)
        {
            items[i] = "key " + i.ToString();
        }




    }

    public void PLayDialogue(GameObject name)
    {
        dialogue = name.GetComponent<AudioSource>();
        if (!dialogue.isPlaying)
        {
            print("play sound for sure");
            dialogue.Play();
        }
    }

    public void DoorOpen(GameObject door, string key)
        {
            //while (inven)
        }


}
